# eco_bot.py - FULL DEPLOY VERSION
import telebot, sqlite3, threading, time, csv, os
from datetime import datetime, timedelta

TOKEN = "7895504257:AAFW_zU3EiS_avZCAYX5JFPMxMz3uJHHeNk"
ADMIN_IDS = [7281379919]

# ... (rest of the full wallet + bidding + staking + referrals + leaderboard + CSV export code)
print("✅ EcoAlliance Bot Running...")
